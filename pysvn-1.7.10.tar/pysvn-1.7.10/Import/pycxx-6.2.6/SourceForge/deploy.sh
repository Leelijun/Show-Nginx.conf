#!/bin/sh
scp index.html barry-scott,cxx@web.sourceforge.net:/home/groups/c/cx/cxx/htdocs/
scp ../README.html barry-scott,cxx@web.sourceforge.net:/home/groups/c/cx/cxx/htdocs/
scp ../Doc/Python2/PyCXX.html barry-scott,cxx@web.sourceforge.net:/home/groups/c/cx/cxx/htdocs/PyCXX-Python2.html
scp ../Doc/Python3/style.css barry-scott,cxx@web.sourceforge.net:/home/groups/c/cx/cxx/htdocs/style.css
scp ../Doc/Python3/PyCXX.html barry-scott,cxx@web.sourceforge.net:/home/groups/c/cx/cxx/htdocs/PyCXX-Python3.html
